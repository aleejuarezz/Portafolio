﻿namespace ConsoleApp1
{
    class Program
    {
        static List<Team> teams = new List<Team>();
        static List<Deck> decks = new List<Deck>();

        static void Main()
        {
            InitializeTeams();
            InitializeDecks();

            while (true)
            {
                Console.WriteLine("Menú Principal");
                Console.WriteLine("1. Ingresar Jugadores");
                Console.WriteLine("2. Ingresar Equipos");
                Console.WriteLine("3. Ingresar Mazos y Cartas");
                Console.WriteLine("4. Jugar");
                Console.WriteLine("5. Ver Mazos");
                Console.WriteLine("6. Equipos");
                Console.WriteLine("7. Salir del programa");
                Console.Write("Seleccione una opción: ");
                int option = int.Parse(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        EnterPlayers();
                        break;
                    case 2:
                        EnterTeams();
                        break;
                    case 3:
                        EnterDecksAndCards();
                        break;
                    case 4:
                        break;
                    case 5:
                        break;
                    case 6:
                        break;
                    case 7:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
                        break;
                }
            }
        }

        static void EnterPlayers()
        {
            Console.WriteLine("Ingrese el nickname de los jugadores:");
            Console.Write("Nickname del jugador 1: ");
            string player1 = Console.ReadLine();
            Console.Write("Nickname del jugador 2: ");
            string player2 = Console.ReadLine();

            teams.Add(new Team("TQ - " + player1));
            teams.Add(new Team("GW - " + player2));
            Console.WriteLine("Jugadores ingresados correctamente.");
        }

        static void EnterTeams()
        {
            Console.WriteLine("Ingrese los nombres de los equipos (por ejemplo, 'Golden Wing', 'Team Queso'):");
            Console.Write("Nombre del equipo 1: ");
            string team1 = Console.ReadLine();
            Console.Write("Nombre del equipo 2: ");
            string team2 = Console.ReadLine();

            teams.Add(new Team(team1));
            teams.Add(new Team(team2));
            Console.WriteLine("Equipos ingresados correctamente.");
        }

        static void EnterDecksAndCards()
        {
            Console.WriteLine("Ingresando mazos y cartas:");
            Console.Write("Nombre del equipo para el nuevo mazo: ");
            string teamName = Console.ReadLine();

            Team team = teams.FirstOrDefault(t => t.Name == teamName);
            if (team == null)
            {
                team = new Team(teamName);
                teams.Add(team);
            }

            Console.Write("Nombre del mazo: ");
            string deckName = Console.ReadLine();
            List<Cartas> cards = new List<Cartas>();

            for (int i = 0; i < 8; i++)
            {
                Console.Write($"Nombre de la carta {i + 1}: ");
                string cardName = Console.ReadLine();
                Console.Write($"Elixir de la carta {i + 1}: ");
                int elixir = int.Parse(Console.ReadLine());
                Console.Write($"Vida de la carta {i + 1}: ");
                int vida = int.Parse(Console.ReadLine());
                Console.Write($"Daño de la carta {i + 1}: ");
                int damage = int.Parse(Console.ReadLine());

                cards.Add(new Cartas(cardName, elixir, vida, damage));
            }

            decks.Add(new Deck(deckName, team, cards));
            Console.WriteLine($"Mazo '{deckName}' ingresado correctamente.");
        }


        static void InitializeDecks()
        {
            decks.Add(new Deck("Hog 2.6 Cycle", new Team("Golden Wing"), new List<Cartas>
        {
            new Cartas("Esqueletos", 1, 119, 119),
            new Cartas("Mozquetera", 4, 1050, 318),
            new Cartas("Monta Puercos", 4, 2472, 463),
            new Cartas("Espíritu de Hielo", 1, 334, 159),
            new Cartas("Golem de Hielo", 2, 1754, 123),
            new Cartas("Cañón", 3, 1197, 308),
            new Cartas("Bola de Fuego", 4, 0, 1004),
            new Cartas("Tronco", 2, 0, 422)
        }));

            decks.Add(new Deck("Giant Mortar", new Team("Golden Wing"), new List<Cartas>
        {
            new Cartas("Arqueras", 3, 0, 0),
            new Cartas("Gigante", 5, 0, 0),
            new Cartas("Ejército de Esqueletos", 3, 0, 0),
            new Cartas("Bebé Dragón", 4, 0, 0),
            new Cartas("Príncipe", 5, 0, 0),
            new Cartas("Mini P.E.K.K.A", 4, 0, 0),
            new Cartas("Duendes con Lanza", 2, 0, 0),
            new Cartas("Mortero", 4, 0, 0)
        }));

            decks.Add(new Deck("Spell Bait", new Team("Team Queso"), new List<Cartas>
        {
            new Cartas("Caballero", 3, 0, 0),
            new Cartas("Princesa", 3, 0, 0),
            new Cartas("Espíritu de Hielo", 1, 0, 0),
            new Cartas("Pandilla de Duendes", 3, 0, 0),
            new Cartas("Torre Infernal", 5, 0, 0),
            new Cartas("Cohete", 6, 0, 0),
            new Cartas("Barril con Duendes", 3, 0, 0),
            new Cartas("Tronco", 2, 0, 0)
        }));

            decks.Add(new Deck("Xbox 2.6", new Team("Team Queso"), new List<Cartas>
        {
            new Cartas("Gigante de Hielo", 2, 0, 0),
            new Cartas("Espíritu de Hielo", 1, 0, 0),
            new Cartas("Tronco", 2, 0, 0),
            new Cartas("Bola de Fuego", 4, 0, 0),
            new Cartas("Ballesta", 6, 0, 0),
            new Cartas("Torre Tesla", 4, 0, 0),
            new Cartas("Esqueletos", 1, 0, 0),
            new Cartas("Arqueras", 3, 0, 0)
        }));
        }

        static void InitializeTeams()
        {
            teams.Add(new Team("Golden Wing"));
            teams.Add(new Team("Team Queso"));
            teams.Add(new Team("Mohamed Light"));
            teams.Add(new Team("iAmJP"));
        }

    }

    class Team
    {
        public string Name { get; }

        public Team(string name)
        {
            Name = name;
        }
    }

    class Deck
    {
        public string Name { get; }
        public Team Team { get; }
        public List<Cartas> Cards { get; }

        public Deck(string name, Team team, List<Cartas> cards)
        {
            Name = name;
            Team = team;
            Cards = cards;
        }

        public double GetTotalElixir()
        {
            double totalElixir = 0;
            foreach (Cartas card in Cards)
            {
                totalElixir += card.ElixirCost;
            }
            return totalElixir;
        }

        public double GetTotalHitPoints()
        {
            double totalHitPoints = 0;
            foreach (Cartas card in Cards)
            {
                totalHitPoints += card.HitPoints;
            }
            return totalHitPoints;
        }

        public double GetTotalDamage()
        {
            double totalDamage = 0;
            foreach (Cartas card in Cards)
            {
                totalDamage += card.Damage;
            }
            return totalDamage;
        }
    }

    class Cartas
    {
        public string Name { get; }
        public int ElixirCost { get; }
        public int HitPoints { get; }
        public int Damage { get; }

        public Cartas(string name, int elixirCost, int hitPoints, int damage)
        {
            Name = name;
            ElixirCost = elixirCost;
            HitPoints = hitPoints;
            Damage = damage;
        }
    }
}