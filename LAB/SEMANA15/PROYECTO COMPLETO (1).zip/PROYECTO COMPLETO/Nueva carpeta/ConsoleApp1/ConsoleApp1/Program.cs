﻿namespace ConsoleApp1
{
    class Program
    {
        static List<Team> teams = new List<Team>();
        static List<Deck> decks = new List<Deck>();

        static void Main()
        {
            InitializeTeams();
            InitializeDecks();

            while (true)
            {
                Console.WriteLine("Menú Principal");
                Console.WriteLine("1. Ingresar Jugadores");
                Console.WriteLine("2. Ingresar Equipos");
                Console.WriteLine("3. Ingresar Mazos y Cartas");
                Console.WriteLine("4. Jugar");
                Console.WriteLine("5. Ver Mazos");
                Console.WriteLine("6. Equipos");
                Console.WriteLine("7. Salir del programa");
                Console.Write("Seleccione una opción: ");
                int option = int.Parse(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        EnterPlayers();
                        break;
                    case 2:
                        EnterTeams();
                        break;
                    case 3:
                        EnterDecksAndCards();
                        break;
                    case 4:
                        Play();
                        break;
                    case 5:
                        ViewDecks();
                        break;
                    case 6:
                        ViewTeams();
                        break;
                    case 7:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
                        break;
                }
            }
        }

        static void EnterPlayers()
        {
            Console.WriteLine("Ingrese el nickname de los jugadores:");
            Console.Write("Nickname del jugador 1: ");
            string player1 = Console.ReadLine();
            Console.Write("Nickname del jugador 2: ");
            string player2 = Console.ReadLine();

            teams.Add(new Team("TQ - " + player1));
            teams.Add(new Team("GW - " + player2));
            Console.WriteLine("Jugadores ingresados correctamente.");
        }

        static void EnterTeams()
        {
            Console.WriteLine("Ingrese los nombres de los equipos (por ejemplo, 'Golden Wing', 'Team Queso'):");
            Console.Write("Nombre del equipo 1: ");
            string team1 = Console.ReadLine();
            Console.Write("Nombre del equipo 2: ");
            string team2 = Console.ReadLine();

            teams.Add(new Team(team1));
            teams.Add(new Team(team2));
            Console.WriteLine("Equipos ingresados correctamente.");
        }

        static void EnterDecksAndCards()
        {
            Console.WriteLine("Ingresando mazos y cartas:");
            Console.Write("Nombre del equipo para el nuevo mazo: ");
            string teamName = Console.ReadLine();

            Team team = teams.FirstOrDefault(t => t.Name == teamName);
            if (team == null)
            {
                team = new Team(teamName);
                teams.Add(team);
            }

            Console.Write("Nombre del mazo: ");
            string deckName = Console.ReadLine();
            List<Cartas> cards = new List<Cartas>();

            for (int i = 0; i < 8; i++)
            {
                Console.Write($"Nombre de la carta {i + 1}: ");
                string cardName = Console.ReadLine();
                Console.Write($"Elixir de la carta {i + 1}: ");
                int elixir = int.Parse(Console.ReadLine());
                Console.Write($"Vida de la carta {i + 1}: ");
                int vida = int.Parse(Console.ReadLine());
                Console.Write($"Daño de la carta {i + 1}: ");
                int damage = int.Parse(Console.ReadLine());

                cards.Add(new Cartas(cardName, elixir, vida, damage));
            }

            decks.Add(new Deck(deckName, team, cards));
            Console.WriteLine($"Mazo '{deckName}' ingresado correctamente.");
        }


        static void InitializeDecks()
        {
            decks.Add(new Deck("Hog 2.6 Cycle", new Team("Golden Wing"), new List<Cartas>
        {
            new Cartas("Esqueletos", 1, 119, 119),
            new Cartas("Mozquetera", 4, 1050, 318),
            new Cartas("Monta Puercos", 4, 2472, 463),
            new Cartas("Espíritu de Hielo", 1, 334, 159),
            new Cartas("Golem de Hielo", 2, 1754, 123),
            new Cartas("Cañón", 3, 1197, 308),
            new Cartas("Bola de Fuego", 4, 0, 1004),
            new Cartas("Tronco", 2, 0, 422)
        })) ;

            decks.Add(new Deck("Giant Mortar", new Team("Golden Wing"), new List<Cartas>
        {
            new Cartas("Arqueras", 3, 367, 143),
            new Cartas("Gigante", 5, 4940, 307),
            new Cartas("Ejército de Esqueletos", 3, 81, 81),
            new Cartas("Bebé Dragón", 4, 1653, 321),
            new Cartas("Príncipe", 5, 1804, 955),
            new Cartas("Mini P.E.K.K.A", 4, 1983, 1050),
            new Cartas("Duendes con Lanza", 2, 229, 115), 
            new Cartas("Mortero", 4, 1813, 352)
        }));

            decks.Add(new Deck("Spell Bait", new Team("Team Queso"), new List<Cartas>
        {
            new Cartas("Caballero", 3, 2566, 293),
            new Cartas("Princesa", 3, 244, 98),
            new Cartas("Espíritu de Hielo", 1, 229, 115),
            new Cartas("Pandilla de Duendes", 3, 229, 115), // Duendes
            new Cartas("Torre Infernal", 5, 2549, 61),
            new Cartas("Cohete", 6, 2163, 541),
            new Cartas("Barril con Duendes", 3, 0, 0), 
            new Cartas("Tronco", 2, 422, 85)
        }));

            decks.Add(new Deck("Xbox 2.6", new Team("Team Queso"), new List<Cartas>
        {
            new Cartas("Gigante de Hielo", 2, 1670, 38),
            new Cartas("Espíritu de Hielo", 1, 230, 167),
            new Cartas("Tronco", 2, 240, 101),
            new Cartas("Bola de Fuego", 4, 832, 832),
            new Cartas("Ballesta", 6, 1330, 26),
            new Cartas("Torre Tesla", 4, 1518, 190),
            new Cartas("Esqueletos", 1, 67, 67),
            new Cartas("Arqueras", 3, 440, 161)
        }));    
        }

        static void InitializeTeams()
        {
            teams.Add(new Team("Golden Wing"));
            teams.Add(new Team("Team Queso"));
            teams.Add(new Team("Mohamed Light"));
            teams.Add(new Team("iAmJP"));
        }

        static void Play()
        {
            if (teams.Count < 2)
            {
                Console.WriteLine("Debe seleccionar al menos 2 equipos antes de jugar.");
                return;
            }

            Console.WriteLine("Equipos disponibles:");
            for (int i = 0; i < teams.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {teams[i].Name}");
            }

            Console.Write("Elija el primer equipo: ");
            int team1Choice = int.Parse(Console.ReadLine()) - 1;
            Console.Write("Elija el segundo equipo: ");
            int team2Choice = int.Parse(Console.ReadLine()) - 1;

            if (team1Choice < 0 || team1Choice >= teams.Count || team2Choice < 0 || team2Choice >= teams.Count)
            {
                Console.WriteLine("Selección de equipos no válida.");
                return;
            }

            Team team1 = teams[team1Choice];
            Team team2 = teams[team2Choice];

            Console.WriteLine("Equipos seleccionados:");
            Console.WriteLine($"1. {team1.Name}");
            Console.WriteLine($"2. {team2.Name}");
            Console.WriteLine("Elija un mazo para cada equipo:");

            Console.WriteLine("Mazos disponibles:");
            for (int i = 0; i < decks.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {decks[i].Name}");
            }

            Console.Write($"Elija un mazo para {team1.Name}: ");
            int team1DeckChoice = int.Parse(Console.ReadLine()) - 1;
            Console.Write($"Elija un mazo para {team2.Name}: ");
            int team2DeckChoice = int.Parse(Console.ReadLine()) - 1;

            if (team1DeckChoice < 0 || team1DeckChoice >= decks.Count || team2DeckChoice < 0 || team2DeckChoice >= decks.Count)
            {
                Console.WriteLine("Selección de mazos no válida.");
                return;
            }
            Deck deck1 = decks[team1DeckChoice];
            Deck deck2 = decks[team2DeckChoice];

            Console.WriteLine($"Mazo seleccionado para {team1.Name}: {deck1.Name}");
            Console.WriteLine($"Mazo seleccionado para {team2.Name}: {deck2.Name}");

            Team winner = CalculateWinner(deck1, deck2);
            Console.WriteLine($"El equipo ganador es: {winner.Name}");
        }

        static void ViewDecks()
        {
            Console.WriteLine("Mazos disponibles:");
            foreach (Deck deck in decks)
            {
                Console.WriteLine(deck.Name);
                Console.WriteLine("Cartas:");
                foreach (Cartas card in deck.Cards)
                {
                    Console.WriteLine($"{card.Name} - Elixir: {card.ElixirCost}, Vida: {card.HitPoints}, Daño: {card.Damage}");
                }
                Console.WriteLine();
            }

            Console.WriteLine("Presione cualquier tecla para regresar.");
            Console.ReadKey();
        }

        static void ViewTeams()
        {
            Console.WriteLine("Equipos registrados:");
            foreach (Team team in teams)
            {
                Console.WriteLine(team.Name);
            }

            Console.WriteLine("Presione cualquier tecla para regresar.");
            Console.ReadKey();
        }

        static Team CalculateWinner(Deck deck1, Deck deck2)
        {
            return deck1.GetTotalElixir() + deck1.GetTotalHitPoints() + deck1.GetTotalDamage() >
                   deck2.GetTotalElixir() + deck2.GetTotalHitPoints() + deck2.GetTotalDamage() ? deck1.Team : deck2.Team;
        }
    }

    class Team
    {
        public string Name { get; }

        public Team(string name)
        {
            Name = name;
        }
    }

    class Deck
    {
        public string Name { get; }
        public Team Team { get; }
        public List<Cartas> Cards { get; }

        public Deck(string name, Team team, List<Cartas> cards)
        {
            Name = name;
            Team = team;
            Cards = cards;
        }

        public double GetTotalElixir()
        {
            double totalElixir = 0;
            foreach (Cartas card in Cards)
            {
                totalElixir += card.ElixirCost;
            }
            return totalElixir;
        }

        public double GetTotalHitPoints()
        {
            double totalHitPoints = 0;
            foreach (Cartas card in Cards)
            {
                totalHitPoints += card.HitPoints;
            }
            return totalHitPoints;
        }

        public double GetTotalDamage()
        {
            double totalDamage = 0;
            foreach (Cartas card in Cards)
            {
                totalDamage += card.Damage;
            }
            return totalDamage;
        }
    }

    class Cartas
    {
        public string Name { get; }
        public int ElixirCost { get; }
        public int HitPoints { get; }
        public int Damage { get; }

        public Cartas(string name, int elixirCost, int hitPoints, int damage)
        {
            Name = name;
            ElixirCost = elixirCost;
            HitPoints = hitPoints;
            Damage = damage;
        }
    }
}