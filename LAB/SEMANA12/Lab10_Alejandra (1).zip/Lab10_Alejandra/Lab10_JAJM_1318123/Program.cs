﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_Alejandra
{
    internal class Program
    {
        static void Main(string[] args)
        {
            TrianguloRectangulo objtriangulo = new TrianguloRectangulo();

            Console.WriteLine("Ingrese el valor de un cateto");
            double CatetoA = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Ingrese el valor del angulo opuesto a este, en grados");
            double OpuestoA = Convert.ToDouble(Console.ReadLine());

            objtriangulo.SetCatetos(CatetoA, OpuestoA);
            objtriangulo.ObtenerDatos();

            Console.ReadKey();
        }
    }
}
