﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T9_JAJM_1318123
{
    using System;

    class Program
    {
        static void Main()
        {
            Motocicleta objMotocicleta = new Motocicleta();

            Console.Write("Modelo: ");
            objMotocicleta.Modelo = int.Parse(Console.ReadLine());

            Console.Write("Marca: ");
            objMotocicleta.Marca = Console.ReadLine();

            Console.Write("Precio sin IVA: ");
            objMotocicleta.DefinirPrecio(double.Parse(Console.ReadLine()));

            Console.Write("Porcentaje de IVA (0.01 a 0.99): ");
            objMotocicleta.DefinirIva(double.Parse(Console.ReadLine()));

            Console.WriteLine("\nDatos de la motocicleta:");
            Console.WriteLine(objMotocicleta.MostrarDatos());

            Console.WriteLine($"\nPrecio sin IVA: {objMotocicleta.PrecioSinIva():C}");
            Console.WriteLine($"Precio con IVA: {objMotocicleta.PrecioConIva():C}");
            Console.WriteLine($"Monto del IVA: {objMotocicleta.DevolverIva():C}");

            Console.ReadKey();
        }
    }


}

