﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L7_AlejandraJuarez_1318123
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtN.Text, out int n) && n > 0)
            {
                double resultadoA = 0;
                double resultadoB = 0;
                int x, a;

                if (int.TryParse(txtX.Text, out x) && int.TryParse(txtA.Text, out a))
                {
                    for (int i = 1; i <= n; i++)
                    {
                        resultadoA += 1.0 / i;
                        resultadoB += 1.0 / Math.Pow(2, i);
                    }

                    double resultadoC = 0;
                    for (int k = 0; k <= n; k++)
                    {
                        resultadoC += Math.Pow(x, k * a) / Math.Pow(n, k);
                    }

                    lblResultadoA.Text = "Resultado (a): " + resultadoA.ToString("F4");
                    lblResultadoB.Text = "Resultado (b): " + resultadoB.ToString("F4");
                    lblResultadoC.Text = "Resultado (c): " + resultadoC.ToString("F4");
                }
                else
                {
                    MessageBox.Show("Ingresa valores válidos para x y a.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Ingresa un valor válido para n (mayor que 0).", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
