﻿namespace L7_AlejandraJuarez_1318123
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbcaja = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtN = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtX = new System.Windows.Forms.TextBox();
            this.txtA = new System.Windows.Forms.TextBox();
            this.lblResultadoA = new System.Windows.Forms.Label();
            this.lblResultadoB = new System.Windows.Forms.Label();
            this.lblResultadoC = new System.Windows.Forms.Label();
            this.gbcaja.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbcaja
            // 
            this.gbcaja.Controls.Add(this.lblResultadoC);
            this.gbcaja.Controls.Add(this.lblResultadoB);
            this.gbcaja.Controls.Add(this.lblResultadoA);
            this.gbcaja.Controls.Add(this.txtA);
            this.gbcaja.Controls.Add(this.txtX);
            this.gbcaja.Controls.Add(this.label2);
            this.gbcaja.Controls.Add(this.label4);
            this.gbcaja.Controls.Add(this.label3);
            this.gbcaja.Controls.Add(this.button1);
            this.gbcaja.Controls.Add(this.txtN);
            this.gbcaja.Controls.Add(this.label1);
            this.gbcaja.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbcaja.Location = new System.Drawing.Point(34, 12);
            this.gbcaja.Name = "gbcaja";
            this.gbcaja.Size = new System.Drawing.Size(730, 414);
            this.gbcaja.TabIndex = 0;
            this.gbcaja.TabStop = false;
            this.gbcaja.Text = "Tarea";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(29, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ingresa un valor para N";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtN
            // 
            this.txtN.Location = new System.Drawing.Point(244, 44);
            this.txtN.Name = "txtN";
            this.txtN.Size = new System.Drawing.Size(122, 28);
            this.txtN.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(127, 170);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(117, 36);
            this.button1.TabIndex = 2;
            this.button1.Text = "Calcular";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(282, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 24);
            this.label3.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(29, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(167, 16);
            this.label4.TabIndex = 5;
            this.label4.Text = "Ingresa un valor para X";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(29, 133);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(168, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Ingresa un valor para A";
            // 
            // txtX
            // 
            this.txtX.Location = new System.Drawing.Point(244, 85);
            this.txtX.Name = "txtX";
            this.txtX.Size = new System.Drawing.Size(122, 28);
            this.txtX.TabIndex = 7;
            // 
            // txtA
            // 
            this.txtA.Location = new System.Drawing.Point(244, 125);
            this.txtA.Name = "txtA";
            this.txtA.Size = new System.Drawing.Size(122, 28);
            this.txtA.TabIndex = 8;
            // 
            // lblResultadoA
            // 
            this.lblResultadoA.AutoSize = true;
            this.lblResultadoA.Location = new System.Drawing.Point(421, 44);
            this.lblResultadoA.Name = "lblResultadoA";
            this.lblResultadoA.Size = new System.Drawing.Size(123, 24);
            this.lblResultadoA.TabIndex = 9;
            this.lblResultadoA.Text = "Resultado A";
            // 
            // lblResultadoB
            // 
            this.lblResultadoB.AutoSize = true;
            this.lblResultadoB.Location = new System.Drawing.Point(421, 85);
            this.lblResultadoB.Name = "lblResultadoB";
            this.lblResultadoB.Size = new System.Drawing.Size(122, 24);
            this.lblResultadoB.TabIndex = 10;
            this.lblResultadoB.Text = "Resultado B";
            // 
            // lblResultadoC
            // 
            this.lblResultadoC.AutoSize = true;
            this.lblResultadoC.Location = new System.Drawing.Point(421, 125);
            this.lblResultadoC.Name = "lblResultadoC";
            this.lblResultadoC.Size = new System.Drawing.Size(123, 24);
            this.lblResultadoC.TabIndex = 11;
            this.lblResultadoC.Text = "Resultado C";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.gbcaja);
            this.Name = "Form1";
            this.Text = "Laboratorio No.7  1318123";
            this.gbcaja.ResumeLayout(false);
            this.gbcaja.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbcaja;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtN;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.TextBox txtX;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblResultadoA;
        private System.Windows.Forms.Label lblResultadoC;
        private System.Windows.Forms.Label lblResultadoB;
    }
}

