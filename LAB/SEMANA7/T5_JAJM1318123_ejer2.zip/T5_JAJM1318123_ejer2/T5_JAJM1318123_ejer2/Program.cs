﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T5_JAJM1318123_ejer2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double Cantidad = 0; double descuento = 0;
            Console.WriteLine("Bienvenido a la tienda");
            Console.WriteLine("Monto de su compra: ");
            Cantidad = Convert.ToDouble(Console.ReadLine());

            if (Cantidad > 0)
            {
                if (Cantidad < 400)
                {
                    descuento = 0;
                }
                else if (Cantidad <= 1000)
                {
                    descuento = Cantidad * 0.07;
                }
                else if (Cantidad <= 5000)
                {
                    descuento = Cantidad * 0.10;
                }
                else if (Cantidad <= 15000)
                {
                    descuento = Cantidad * 0.15;
                }
                else
                {
                    descuento = Cantidad * 0.25;
                }
                Console.WriteLine("Precio a pagar es de " + (Cantidad - descuento));
            }
            else
            {
                Console.WriteLine("ERROR");
                Console.WriteLine("El monto de compra no puede ser negativo");
            }
            Console.ReadKey();
        }
    }
    }

